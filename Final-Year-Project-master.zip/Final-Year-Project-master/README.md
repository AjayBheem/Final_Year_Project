<h4>B.Tech Final Year Project</h4>
<h4>PROJECT TITLE : NEXT GENERATION APPROACH FOR EXAM HALL DISTRIBUTION THROUGH UNIQUE AND ANAMOLUS SEMANTIC TECHNIQUES</h4>
<h6>Problem Statement : The traditional manual exam seating arrangement process is prone to errors, time-consuming and lacks of efficiency. Challenges such as data inaccuracies,cumbersome seat allocation and manual communication pose significant hurdles.To address these issues the "Next Generation Approach For Enhancing Exam Hall Distribution Through Unique And Anomalous Semantic Techniques" is proposed.</h6>
<h6>Technology Used : Python with Django Framework.</h6>

<h6>Downloadable Reports:</h6>
<h6>1.Excel Report : A complete seat allotment report is generated in Excel format for download.</h6>
<h6>2.Department Wise PDF Report : This report provides department-wise seat allotment information in PDF format.</h6>
<h6>3.Room Wise PDF Report : This report offers room-wise seat allotment details in PDF format.</h6>




